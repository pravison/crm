from django.conf import settings 
from django.db.models import Count, Q
from datetime import  date, datetime, timedelta
from django.utils import timezone
from customers.models import Conversation, Customer, Interaction
import requests
import openai
from ai.models import TaskPipeline, Escalation, AI_Agent, SalesFunnelStageInstruction, AiReport,  Whatsapp
from clients.models import Client
# from store.models import Product, PromotionalCampaign


# Set up OpenAI API key 
openai.api_key =settings.OPENAI_API_KEY

def receiveCall(audio):
    pass

def callClient(audio):
    pass


#######################################################################################################################################################
# sending message to whatsap
########################################################################################################################################################


def sendWhatsappMessage(fromId, message):
    whatsapp = Whatsapp.objects.order_by("id").first()
    whatsapp_url = f'https://graph.facebook.com/v20.0/{whatsapp.whatsapp_phone_number_id}/messages'
    whatsapp_token =f'Bearer {whatsapp.whatsapp_auth_token}'
    headers = {"Authorization" : whatsapp_token}
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type" : "individual",
        "to": fromId,
        "type":"text",
        "text":{"body": message}
        }
    requests.post(whatsapp_url, headers=headers, json=payload)
    return True


#######################################################################################################################################################
# ___________cutomer support agent________________________________
########################################################################################################################################################
    

# ductionary containing follow up instruction , depending on sales funnel stages 
FOLLOW_UP_INSTRUCTIONS = {
    'awareness': """
            Goal: Introduce your product/service.
            SOP:

            Research the target market and audience.
            Call, SMS, or WhatsApp the customer to introduce your product and its value.
            Keep the message short, highlighting a key problem and your solution.
            End with a clear CTA (e.g., schedule a call, visit website, or download resources).
            Log responses to track who shows interest for follow-up.
        """,
    'interest': """
            Goal: Engage prospects who show interest.
            SOP:
            Segment leads based on initial responses or missed calls.
            Call or WhatsApp them within 24-48 hours to follow up on their interest.
            Send personalized content via WhatsApp or SMS (e.g., case studies, testimonials).
            Offer to answer any questions or schedule a live demo.
            Track their engagement by noting call responses or content read in WhatsApp.
        """,
    'decision': """
            Goal: Help prospects evaluate and choose your solution.
            SOP:

            Call them to provide a tailored offer or clarify product features.
            Use WhatsApp or SMS to send product comparisons or limited-time promotions.
            Offer to schedule a one-on-one demo or consultation.
            Handle objections by discussing concerns over the call or sending clarifying information via SMS.
            Set up a follow-up call at a convenient time to keep the conversation going.
        """,
    'purchase': """
            Goal: Convert leads into paying customers.
            SOP:

            Call to guide them through the purchase process and confirm details.
            Use WhatsApp or SMS to provide payment links or instructions.
            Send a confirmation message once the purchase is completed.
            Offer immediate support through WhatsApp or phone to ensure a smooth transition.
            Request a review or referral via WhatsApp after successful onboarding.
        """,
    'active': """
            Goal: Retain and upsell existing customers.
            SOP:

            Call regularly to check on their satisfaction and ensure they’re utilizing the product fully.
            Send updates, new feature announcements, or upsell options through WhatsApp or SMS.
            Offer personalized promotions or loyalty discounts via phone or message.
            Provide a direct support line for them to contact you easily via phone or WhatsApp.
            Gather feedback through phone calls to strengthen the customer relationship.
        """,  
    'dormant': """
            Goal: Re-engage inactive customers.
            SOP:

            Identify dormant customers through CRM.
            Call to check in and remind them of your services.
            Send personalized re-engagement offers via WhatsApp or SMS.
            Highlight key benefits or provide a special offer to encourage action.
            Log responses from calls or messages and adjust future re-engagement strategies based on their feedback.
        """,  
}


# Define keywords or phrases that indicate the customer is busy
BUSY_KEYWORDS = [
    "busy", "call later", "can't talk now", "react out later", "later", "another time", "not now", "contact me next month"
]

def is_customer_busy(customer_message):
    """
    Check if the customer's message indicates they are busy.

    Parameters:
    - customer_message (str): The message from the customer.

    Returns:
    - bool: True if the customer is busy, False otherwise.
    """
    message = customer_message.lower()
    return any(keyword in  message for keyword in BUSY_KEYWORDS)

from django.utils import timezone

def get_company_promotions():
    """
    Retrieve a company's active promotions in an array format.

    Returns:
    - list: A list of dictionaries, with each dictionary containing promotion details.
    """
    current_date = timezone.now().date()
    
    # Filter promotions based on active date range
    promotions = PromotionalCampaign.objects.filter(
        start_date__lte=current_date,
        end_date__gte=current_date
    )
    
    if not promotions.exists():
        return []
    
    # Build a list of promotion dictionaries
    company_promotions = [
        {
            "campaign": promotion.campaign,
            "applied_to_all": promotion.applied_to_all,
            "choose_products": promotion.choose_products
        }
        for promotion in promotions
    ]
    
    return company_promotions


def get_company_products():
    """
    Retrieve a company's products in an array format.

    Parameters:
    - customer (Customer object): The customer to retrieve products for.

    Returns:
    - tuple: A list of dictionaries with each dictionary containing product details,
             and a flag indicating if no products are found.
    """
    # Assuming Product has a foreign key to Company, which has a foreign key to Customer
    products = Product.objects.all()
    
    if not products.exists():
        return [], True
    
    # Build a list of product dictionaries
    company_products = [
        {
            "name": product.name,
            "price": product.price,
            "description": product.description,
            # Add other parameters as needed
        }
        for product in products
    ]
    
    return company_products, False


def get_past_conversations(customer):
    """
    Retrieve past conversation history for the given customer.

    Parameters:
    - customer (Customer object): The customer whose conversation history we want to retrieve.

    Returns:
    - str: A string representing the concatenated past conversation history.
    - bool: A flag indicating whether this is the customer's first interaction.
    """
    chats = Conversation.objects.filter(customer=customer).order_by('timestamp')
    
    if not chats.exists():
        # No previous chats, so it's the first interaction
        return "", True
    
    conversation_history = ""
    
    for chat in chats:
        if chat.sender =='customer':
            conversation_history += f"Customer: {chat.message}\n"
        else:
            conversation_history += f"AI: {chat.message}\n"
    
    return conversation_history, False


def save_conversation(customer, message, sender):
    # Save AI's response
    Conversation.objects.create(
        customer=customer,
        message=message,
        sender=sender
    )



def escalation_needed(agent, customer, customer_message, ai_response):
    """
    Check if the AI response indicates the need for escalation.

    Parameters:
    - ai_response (str): The response generated by the AI.

    Returns:
    - bool: True if escalation is needed, False otherwise.
    """
    escalation_keywords = ['escalate', 'help from human', 'support agent', 'can’t assist', 'need human']
    
    # Check if any escalation keyword is in the AI response
    if any(keyword in customer_message.lower() for keyword in escalation_keywords):
        escalate, created = Escalation.objects.get_or_create(customer=customer)
    
        # Assuming you have fields follow_up_date and follow_up_time in TaskPipeline
        escalate.reasons = customer_message
        escalate.save()
        if agent.escalation_notification:
            if agent.whatsapp_number_1:
                fromId = agent.whatsapp_number_1
                customer_name = f'{customer.name} - phone number {customer.phone_number}' if customer.name else customer.phone_number
                message = f'i have escaleted {customer_name} i was unable to help, customers querry was: {customer_message}'
                sendWhatsappMessage(fromId, message)
            if agent.whatsapp_number_2:
                fromId = agent.whatsapp_number_1
                customer_name = f'{customer.name} - phone number {customer.phone_number}' if customer.name else customer.phone_number
                message = f'i have escaleted {customer_name}i was unable to help, customers querry was {customer_message}'
                sendWhatsappMessage(fromId, message)

    elif any(keyword in ai_response.lower() for keyword in escalation_keywords):
        escalate, created = Escalation.objects.get_or_create(customer=customer)
    
        # Assuming you have fields follow_up_date and follow_up_time in TaskPipeline
        escalate.reasons = customer_message
        escalate.save()
        if agent.escalation_notification:
            if agent.whatsapp_number_1:
                fromId = agent.whatsapp_number_1
                customer_name = f'{customer.name} - phone number {customer.phone_number}' if customer.name else customer.phone_number
                message = f'i have responded to {customer_name} query which was {customer_message}'
                sendWhatsappMessage(fromId, message)
            if agent.whatsapp_number_2:
                fromId = agent.whatsapp_number_1
                customer_name = f'{customer.name} - phone number {customer.phone_number}' if customer.name else customer.phone_number
                message = f'i have responded to {customer_name} query which was {customer_message}'
                sendWhatsappMessage(fromId, message)
    return ''


def update_funnel_stage(customer, customer_message):
    """
    Update the customer's sales funnel stage based on their message.

    Parameters:
    - customer (Customer object): The customer record from the database.
    - customer_message (str): The latest message from the customer.

    Returns:
    - new_funnel_stage (str): Updated funnel stage for the customer.
    """
    if any(keyword in customer_message.lower() for keyword in ["interested","intrested", "details", "more information"]):
        new_funnel_stage = "interest"
    elif any(keyword in customer_message.lower() for keyword in ["ready", "purchase", "buy"]):
        new_funnel_stage = "decision"
        # update this other funnels stages later 
    # elif any(keyword in customer_message.lower() for keyword in ["ready", "purchase", "buy"]):
    #     new_funnel_stage = "purcahse"
    # elif any(keyword in customer_message.lower() for keyword in ["ready", "purchase", "buy"]):
    #     new_funnel_stage = "active"
    # elif any(keyword in customer_message.lower() for keyword in ["ready", "purchase", "buy"]):
    #     new_funnel_stage = "dormant"
    else:
        new_funnel_stage = customer.funnel_stage 

    # Update the funnel stage in the database (pseudo-code)
    customer.funnel_stage = new_funnel_stage
    customer.save()

    return new_funnel_stage



def handle_customer_query(customer_message, customer):
    """
    Handles a customer query, introducing yourself on the first interaction while responding to the query.

    Parameters:
    - customer_message (str): The new message from the customer.
    - customer_data (dict): Information about the customer, including name, company, and funnel stage.

    Returns:
    - AI response, new funnel stage, escalation flag
    """
    company, created = CompanyInformation.objects.get_or_create(id=1, defaults={"company_name": "Your Site"})
    agent = AI_Agent.objects.all().order_by('id').first()
    if not agent:
        agent = AI_Agent.objects.create(agent_name="sales agent")

    #company products 
    products , no_products = get_company_products()
    if not products:
        products = company.products_summary

    promotions = get_company_promotions()

    # Get the past conversation history and check if it's the first interaction
    past_history, is_first_interaction = get_past_conversations(customer)

    # Prepare the introduction message if it's the first interaction
    if is_first_interaction:
        introduction_message = f"Hello! I’m {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'SalesGenie'}, your AI assistant working with {company.company_name if company and hasattr(company, 'acompany_name') else 'Salesflow Pro'}. "
    else:
        introduction_message = ""

    
    instructions = SalesFunnelStageInstruction.objects.filter(funnel_stage=customer.funnel_stage).first()
    if instructions:
       follow_up_instructions= SalesFunnelStageInstruction.objects.filter(funnel_stage=customer.funnel_stage).first()
    else:
        follow_up_instructions= FOLLOW_UP_INSTRUCTIONS.get(customer.funnel_stage, """
            Goal: Engage prospects who show interest.
            SOP:
            Segment leads based on initial responses or missed calls.
            Call or WhatsApp them within 24-48 hours to follow up on their interest.
            Send personalized content via WhatsApp or SMS (e.g., case studies, testimonials).
            Offer to answer any questions or schedule a live demo.
            Track their engagement by noting call responses or content read in WhatsApp.
        """)
    # Prepare the full prompt including the introduction if necessary
    if company.field_of_operation == "software as a service" :
        prompt = f"""
        here is our: 
        company description : {company.company_description}.
        product/service you're selling: {products}.
        current promtions and camapigns are {promotions}
        
        Act as an experienced AI sales agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, working for {company.company_name} targeting real estate agents and software/SaaS sellers. Your primary goal is to initiate and nurture meaningful conversations that lead to sales conversions, adapting your responses based on the lead's stage in the sales funnel (cold, warm, or hot). Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, tailoring to the following specifics:

        1. Customer Engagement and Questioning (SPIN Framework):
        Cold Leads: Focus on Situation questions to gather context and understand business goals.
        Warm Leads: Transition more quickly into Problem and Implication questions to uncover pain points.
        Hot Leads: Focus on Need-Payoff questions, emphasizing AI’s specific benefits (e.g., better lead conversion, cost savings).
        2. Building Influence and Authority (Cialdini’s Principles):
        Use reciprocity by offering value-first tips or resources.
        Authority: Display expertise by referencing successful case studies and client testimonials.
        Social Proof: Tailor success stories to the lead’s industry (e.g., real estate or SaaS).
        3. Challenging Clients’ Perspectives (The Challenger Sale):
        Gently challenge leads’ current thinking, especially for leads who are unsure about AI. Position AI as a solution to untapped opportunities, such as improving lead qualification or boosting outreach efficiency.
        4. Objection Handling and Escalation:
        Address objections with solution-oriented responses. If the objection is complex, smoothly escalate to a human representative, offering to connect the lead to an expert.
        5. Conversational Flow:
        Always ask follow-up questions to ensure engagement. Adapt follow-up questions based on lead responses, and maintain a natural flow in the conversation. Example follow-up questions include: “What do you think about this feature?” or “What challenges are you currently facing in your business?”
        6. Tailoring Responses to Specific Needs:
        For Real Estate Agents: Focus on urgency, market trends, and local property features.
        For SaaS Sellers: Emphasize ROI, scalability, and lead management efficiency.
        7. End Goal:
        Continuously steer the conversation towards conversion. Reiterate the AI's benefits, offer a demo, or suggest next steps, such as booking a call or receiving additional details.
        Below is the past conversation history: {past_history}
        Now, the customer said: "{customer_message}" 
        make the message consise and to the point, easy to profread and not more than 350 characters unless asked for indepth explanation
        make the message flow one th feels to have been wwritten by human and design for whatsapp chat
        """
    elif company.field_of_operation == "real estate" :  
        prompt = f"""
        here is our: 
        company description : {company.company_description}.
        product/service you're selling: {products}.
        current promtions and camapigns are {promotions}
        Act as an experienced AI real estate sales agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, working for {company.company_name} targeting clients looking for rental properties, first homes, or real estate investments. Your primary goal is to initiate and nurture meaningful conversations that guide clients to the right property options, adapting your responses based on the client’s stage in the decision-making process (exploring, evaluating, or ready to purchase). Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, tailoring to the following specifics:

        Customer Engagement and Questioning (SPIN Framework):

        Exploring Clients: Begin with Situation questions to gather context on what they are looking for (rental, first home, or investment).
        Evaluating Clients: Move into Problem and Implication questions to identify their specific needs and pain points (e.g., location preferences, budget constraints).
        Ready to Purchase Clients: Focus on Need-Payoff questions, highlighting how the AI can offer the best deals, investment opportunities, or rental options to save them time and money.
        Building Influence and Authority (Cialdini’s Principles):

        Reciprocity: Provide valuable insights such as market trends, advice on the home-buying process, or investment tips in return for their trust.
        Authority: Display expertise by referencing successful cases of clients finding their ideal properties or successful investment deals.
        Social Proof: Share success stories from clients who have successfully rented homes, purchased their first properties, or made profitable investments, tailored to their specific situation (e.g., first-time home buyers or rental seekers).
        Challenging Clients’ Perspectives (The Challenger Sale):

        For Clients Uncertain About Property Choices: Gently challenge their current thinking by introducing new possibilities or properties they may not have considered. Position the AI as a solution to help them discover hidden gems, better investment opportunities, or properties that align more closely with their needs.
        For Investment Seekers: Encourage clients to explore alternative investment strategies or properties with higher potential returns, focusing on market growth areas or emerging investment opportunities.
        Objection Handling and Escalation:

        Address objections about pricing, location, or property features with solution-oriented responses, offering alternatives that still meet their needs.
        If the client expresses concern about the AI’s recommendations or asks a complex question, escalate the conversation to a human real estate expert, offering to schedule a consultation with an agent for more tailored advice.
        Conversational Flow:

        Always ask follow-up questions to ensure engagement and move the conversation forward. Adapt follow-up questions based on the client’s responses, such as: “What’s your timeline for moving?” or “What’s most important to you when selecting a property?”
        If a client mentions a budget range, ask about their desired amenities or location to refine the search.
        Tailoring Responses to Specific Needs:

        For Rental Clients: Focus on rental prices, lease terms, amenities, and the neighborhood.
        For First-Time Homebuyers: Emphasize affordability, financing options, and proximity to work, schools, or family.
        For Real Estate Investors: Highlight ROI potential, investment strategies, property appreciation rates, and rental income.
        End Goal:

        Continuously steer the conversation towards a property recommendation or action step. Reiterate the AI's ability to simplify property searches, provide valuable market insights, and save time in finding the right match.
        Suggest next steps like scheduling a property tour, receiving property details, or discussing financing options with a human agent.
        Below is the past conversation history: {past_history}
        Now, the customer said: "{customer_message}" 
        make the message consise and to the point, easy to profread and not more than 350 characters unless asked for indepth explanation
        make the message flow one th feels to have been wwritten by human and design for whatsapp chat
        """
    elif company.field_of_operation == "automotive" :
        prompt = f"""
            here is our: 
            company description : {company.company_description}.
            product/service you're selling: {products}.
            current promtions and camapigns are {promotions}

            Act as an experienced AI automotive sales agent targeting clients interested in purchasing their dream car, whether it’s a first-time buy, an upgrade, or an investment in a premium vehicle. Your primary goal is to initiate and nurture meaningful conversations that guide clients toward the right car choices, adjusting responses based on the client’s stage in the decision-making process (exploring, evaluating, or ready to purchase). Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, with the following focus areas:

            Customer Engagement and Questioning (SPIN Framework):

            Exploring Clients: Start with Situation questions to understand the client’s general preferences, lifestyle, and what they’re looking for in a car (e.g., family-friendly, luxury, eco-friendly, or performance). Ask openers like, “What’s most important to you in a vehicle—fuel efficiency, comfort, or performance?” to tailor recommendations effectively.

            Evaluating Clients: Shift to Problem and Implication questions, digging deeper into specific needs and challenges, such as budget limits, desired features, or specific models under consideration. Use questions like, “Are you looking for any specific safety features or technology?” to clarify their priorities and uncover potential deal-breakers.

            Ready to Purchase Clients: Focus on Need-Payoff questions that highlight how the AI can provide unique options or help with exclusive financing and limited-time offers (e.g., “Would you be interested in a test drive for our latest model with all the features you’re looking for?”).

            Building Influence and Authority (Cialdini’s Principles):

            Reciprocity: Share valuable insights, such as recent trends in fuel-efficient models, maintenance tips, or updates on the best financing options. This builds trust and provides added value, e.g., “I can share a quick guide on maintaining the longevity of your vehicle—would you like that?”

            Authority: Establish expertise by referencing successful matches, such as helping clients find family SUVs with top safety ratings or matching buyers to luxury vehicles with exceptional resale value. Reinforce your knowledge by explaining unique vehicle benefits in layman’s terms.

            Social Proof: Reference stories from similar clients who successfully found their dream cars—whether a family-friendly SUV, a high-performance sedan, or an eco-friendly hybrid. Example: “Many of my clients have found value in our selection of fuel-efficient models for commuting—would you like to explore those?”

            Challenging Clients’ Perspectives (The Challenger Sale):

            For Clients Who Haven't Considered All Options: Suggest alternative options that align with their lifestyle but add value, e.g., “Have you considered our newest hybrid model? It combines fuel efficiency with high performance and has been popular among clients looking to reduce fuel costs.”

            For Performance or Investment Buyers: Introduce them to models with high resale value or limited edition features, encouraging them to consider cars that provide better long-term value. Example: “Many clients find that investing in a model with high resale potential is beneficial—would you like more details on those options?”

            Objection Handling and Escalation:

            Address Objections: Tackle concerns about budget, features, or vehicle type with solution-oriented responses. For instance, “If budget is a concern, we could look at pre-owned certified vehicles with the same features—would that interest you?”

            Escalate to Expert Assistance: If they have complex questions about financing, trade-ins, or customization, seamlessly escalate to a human sales expert, offering to set up a call or appointment for a deeper discussion.

            Conversational Flow and Follow-up:

            Keep Engagement High: Use follow-up questions based on prior interactions, like “What’s your ideal timeline for purchasing?” or “Would you like to schedule a test drive to see how it feels?”

            Build Long-Term Engagement: Track client preferences and reference them in follow-up messages to show attentiveness, e.g., “I remember you mentioned an interest in fuel efficiency—would you like an update on some of the latest hybrid models?”

            Tailoring Responses to Specific Needs:

            For First-Time Buyers: Focus on budget-friendly, reliable options and financing assistance. Emphasize affordability, easy maintenance, and warranties, with prompts like “Would knowing about financing options help you with budgeting?”

            For Upgraders: Highlight features that represent an upgrade, like advanced tech, safety features, and enhanced comfort. Example: “Would you like to see vehicles with the latest tech features and a bit more space?”

            For Investment or Premium Buyers: Emphasize luxury, unique features, and models with high resale value. Discuss rare options, customizations, or market trends, with questions like “Are you interested in exploring vehicles with exclusive features or limited availability?”

            End Goal:

            Steer Toward Action: Guide clients toward scheduling a test drive, receiving a tailored car list, or discussing financing options with a human agent.

            Use Actionable CTAs: Close with action prompts like, “Would you like to book a test drive this week?” or “I can connect you with a financing specialist if you’re ready to explore payment options.
            Below is the past conversation history: {past_history}
            Now, the customer said: "{customer_message}"
            make the message consise and to the point, easy to profread and not more than 350 characters unless asked for indepth explanation
            make the message flow one th feels to have been wwritten by human and design for whatsapp chat
            """
    else:    
        prompt = f"""
        {introduction_message}

        
        You're an AI sales assistant named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, working for {company.company_name} and specializing in helping customers choose products that best meet their needs while enhancing their confidence in buying from us. Use the following process to tailor your responses to each customer, depending on their purchasing stage and preferences. Keep the conversation professional, friendly, and supportive.  
        **Language Adaptation**:
        - Respond based on the customer’s language preference: If the customer uses full English, reply in English. If they use full Kiswahili, reply in Kiswahili. If they use a mix of both, respond similarly with a mix of both languages. asses which language to use basically depending on the last message  

        ** Customer Name **:
        - politely and creatively ask for customers name 

        1. **Determine Customer Needs and Priorities**:
        - Ask questions to understand the customer’s intended use, such as, 'How do you plan to use this product?' or 'What will be the primary use—work, gaming, multimedia, or general use?'
        - Identify specific feature preferences (e.g., screen size, battery life, portability, camera quality) by asking, 'Are there any specific features you’re looking for?'
        - Find out the customer’s budget range by asking, 'What budget range do you have in mind for this purchase?' Make recommendations within that range while highlighting the best value options.

        2. **Build Trust and Familiarity**:
        - Ask if they have a brand or model preference, and provide relevant options based on those preferences. Use familiarity with a brand to strengthen the recommendation, or suggest comparable alternatives to broaden their choices.
        - Inquire about any concerns or challenges they’ve faced with similar products, addressing past issues with solutions available in the products you recommend.

        3. **Present Options with Added Value**:
        - Tailor your suggestions based on the frequency and type of use they expect. For example, frequent users may need durability, battery life, or warranty benefits. Emphasize products with solid after-sales support or extended warranties if appropriate.
        - Explain any available promotions or bundles that match their interests and create more value in their purchase. For customers nearing a decision, reinforce the benefits of acting on current promotions, such as limited-time discounts or special bundle offers.

        4. **Support Decision-Making Based on Purchase Readiness**:
        - Determine if the customer is ready to purchase or still in the research phase. If ready, highlight time-sensitive promotions if exists dont come up with your own, or reassure them with easy return options or in-store pickup. For researchers, share relevant resources like product comparisons or demo videos to assist in their evaluation.
        - creatively create an urgency for customer to act fast
        - Encourage customers to consider add-ons like accessories, extended warranties, or software if it enhances their experience with the product.

        5. **Highlight the Quality of Service and Customer Experience**:
        - Reassure the customer of the after-sales support, warranties, and assistance that come with their purchase from us. Emphasize the brand’s dedication to quality and support that sets us apart from competitors.
        - Offer peace of mind by highlighting benefits like secure checkout, reliable shipping, and easy return policies.

        6. **Build a Lasting Relationship**:
        - After the purchase, encourage engagement with our post-purchase services, like tutorials or setup guides tailored to their product. Offer loyalty discounts or future purchase incentives to foster customer loyalty.

        When providing information to customers, use insights from customer previous intrested products, 
        recent campaigns, and promotions to make your responses specific, timely, and relevant. 
        Reference their saved views and chat history to customize responses based on products they’ve shown interest in. Be mindful of the customer’s stage in the buying journey, and prioritize clear, value-oriented guidance that supports their purchasing confidence.
        never hullucinate if you don't acces to the required answer escalete the customer and respond back you are escalating the request to human agent
        If escalation is needed, just reply you will be escalated to hunan agent to be assisted.
        
        
        
        The company description  is {company.company_description}.
        The product/service you're promoting is {products}.
        company promtions and camapigns are {promotions}
        Below is the past conversation history: {past_history}

        Guidelines for your response:
        - Use a friendly, engaging tone.
        {follow_up_instructions}

        Now, the customer said: "{customer_message}" 
        make the message consise and to the point, easy to profread and not more than 350 characters unless asked for indepth explanation
        make the message flow one th feels to have been wwritten by human and design for whatsapp chat
        """

    # Call OpenAI API to generate a response based on the dynamic prompt
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are an expert AI sales Agent."},
            {"role": "user", "content": prompt}
        ]
    )

    # Parse the response
    ai_response = response['choices'][0]['message']['content']
    sender = "AI"
    message = ai_response
    save_conversation(customer, message, sender)

    # handle escalations
    escalation_needed(agent, customer, customer_message, ai_response)

    # handle Update funnel stage based on customer message (e.g., based on keywords like "interested")
    update_funnel_stage(customer, customer_message)

    
    if agent.respond_notification:
        if agent.whatsapp_number_1:
            fromId = agent.whatsapp_number_1
            customer_name = customer.name if customer.name else customer.phone_number
            message = f'i have responded to {customer_name} query which was {customer_message}'
            sendWhatsappMessage(fromId, message)
        if agent.whatsapp_number_2:
            fromId = agent.whatsapp_number_1
            customer_name = customer.name if customer.name else customer.phone_number
            message = f'i have responded to {customer_name} query which was {customer_message}'
            sendWhatsappMessage(fromId, message)
    return ai_response  


import re

def extract_time(message):
    """
    Extracts time from the message using regex to handle formats like '3pm', '15:00', etc.
    """
    time_pattern = r'(\d{1,2}(?::\d{2})?\s?(?:am|pm)?)'
    match = re.search(time_pattern, message, re.IGNORECASE)
    if match:
        return match.group(0)
    return None

def extract_follow_up_datetime(customer_message):
    """
    Extracts a follow-up date and time from the customer's message.
    
    Returns a datetime object or None if parsing fails.
    """
    customer_message = customer_message.lower()

    # Default follow-up date is today
    follow_up_date = datetime.now()

    # Check for keywords like 'tomorrow' and adjust the date
    if "tomorrow" in customer_message:
        follow_up_date = follow_up_date + timedelta(days=1)

    # You can add more logic for other keywords like "next week", etc.

    # Extract the time from the message
    time_str = extract_time(customer_message)

    if time_str:
        # Parse the time (e.g., '3pm' -> '15:00')
        follow_up_time = datetime.strptime(time_str, '%I%p' if 'pm' in time_str or 'am' in time_str else '%H:%M').time()
        follow_up_datetime = datetime.combine(follow_up_date, follow_up_time)
    else:
        # If no time is found, return the default date (just the day, no specific time)
        follow_up_datetime = follow_up_date

    print(f"Extracted datetime: {follow_up_datetime}")
    return follow_up_datetime


def update_follow_up_in_task_pipeline(task_pipeline, follow_up_datetime):
    """
    Updates the TaskPipeline for the customer with the provided follow-up time and date.

    Parameters:
    - customer: The customer object.
    - follow_up_date: The date for follow-up.
    - follow_up_time: The time for follow-up.

    Returns:
    - None
    """
    # Assuming you have fields follow_up_date and follow_up_time in TaskPipeline
    task_pipeline.follow_up_date = follow_up_datetime.date()
    task_pipeline.follow_up_time = follow_up_datetime.time()
    
    task_pipeline.save()

def extract_name(customer_message):
    # A simple regex pattern to match a name (capitalize the first letter)
    pattern = r'\b(?:my name is| | am |I am|I’m|my name’s| naitwa | najulikana kama| jina langu ni?)\s+([A-Z][a-z]+)\b'
    match = re.search(pattern, customer_message, re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def handle_customer_query_with_follow_up(customer_message, fromId):
    """
    Handles a customer query, detecting if the customer is busy and handling follow-up scheduling.

    Parameters:
    - customer_message (str): The new message from the customer.
    - customer_data (dict): Information about the customer, including name and funnel stage.

    Returns:
    - AI response, updated funnel stage, escalation flag
    """
    #getting customer 
    customer, created = Customer.objects.get_or_create(
            phone_number=fromId
        )
    #adding this to last time talked with the customer
    customer.last_talked = timezone.now().date()
    customer.save()
    #getting the previous chat 
    # previous_chat = Conversation.objects.filter(customer=customer ).order_by('-timestamp').first()
    # last_chat = previous_chat if previous_chat is not None else ""
    # Check if customer indicates they are busy
    # if cust
    if is_customer_busy(customer_message):
        # AI response asking for a convenient time and date
        ai_response = f"Thank you for letting me know! I appreciate your time. Could you please let me know a more convenient time and date for us to follow up?"

        # Save this interaction in the TaskPipeline for later follow-up
        task_pipeline, created = TaskPipeline.objects.get_or_create(customer=customer)
        # task_pipeline.follow_up_scheduled = True
        task_pipeline.save()

        #  the above function was trying to extract time and date and be able to add it to task pipeline but it does not work 

        follow_up_datetime = extract_follow_up_datetime(customer_message)

        if follow_up_datetime:
            ai_response = f"Thank you! I have scheduled a follow-up for {follow_up_datetime.strftime('%A, %B %d at %I:%M %p')}."
            update_follow_up_in_task_pipeline(task_pipeline, follow_up_datetime)
        else:
            ai_response = "Sorry, I couldn't understand the follow-up time. Could you please provide a specific time and date?"

        return ai_response
   
    else:
        # wanted to extract name and save it
        # chat = Conversation.objects.filter(customer=customer, sender='AI').order_by('-id').first()
        # if chat:
        #     name_keywords = ['your name', 'share your name', 'know your name']
        #     if any(keyword in chat.lower() for keyword in name_keywords):
        #         if not customer.name:  # Only run if customer has no name
        #             name = extract_name(customer_message)
        #             if name:  # Check if a name was successfully extracted
        #                 customer.name = name
        #                 customer.save()
        
        return handle_customer_query(customer_message, customer)



#bring it all together 
#lets define the function thart talk to webhook
def handleWhatsappCall(fromId, customer_message):
    message = handle_customer_query_with_follow_up(customer_message, fromId)
    sendWhatsappMessage(fromId, message)
    

#######################################################################################################################################################
# leads warmup agent
########################################################################################################################################################

# function that checks the last time customer was called and the add customer to TaskPipeline

# Define the minimum follow-up days for each funnel stage
FOLLOW_UP_DAYS = {
    'awareness': 5,
    'interest': 3,
    'decision': 2,
    'purchase': 1,
    'active': 7,   # Assuming 1-2 weeks; using the minimum of 7 days
    'dormant': 30  # Assuming 30-60 days; using the minimum of 30 days
}

def add_customers_to_pipeline():
    # Get the current date
    current_date = timezone.now().date()
    
    agent = AI_Agent.objects.all().order_by('id').first()
    if not agent:
        agent = AI_Agent.objects.create(agent_name="sales agent")
    # Get all customers who haven't been talked to recently based on their funnel stage
    customers_to_follow_up = Customer.objects.all()
    total_follow_up = 0
    # Iterate over each customer and determine if they need a follow-up
    for customer in customers_to_follow_up:
        # lets get how many days to follow up after last interaction
        instructions = SalesFunnelStageInstruction.objects.filter(funnel_stage=customer.funnel_stage).first()
        # Get the follow-up threshold based on the customer's funnel stage
        if instructions:
            days = instructions.days_to_follow_up
        else:
            days = FOLLOW_UP_DAYS.get(customer.funnel_stage, 3) # Default to 3 days if no stage matches
        follow_up_days = days  
        
        # Check if the last talked date exceeds the threshold
        if customer.last_talked <= current_date - timedelta(days=follow_up_days):
            # Check if the customer is already in the pipeline and the task is not done
            existing_task = TaskPipeline.objects.filter(customer=customer, done=False).exists()
            
            if not existing_task:  # Only add if no active task exists
                TaskPipeline.objects.create(
                    customer=customer,
                    task = 'follow up with the customer',
                    follow_up_date=current_date, # + timedelta(days=1),  # Set follow-up date for the next day
                    follow_up_time=None,  # You can set a default time here if needed
                )
                total_follow_up +=1

    if total_follow_up == 0:
        if agent.follow_up_notification | agent.midday_report_notification | agent.evening_report_notification:
            if agent.whatsapp_number_1:
                fromId = agent.whatsapp_number_1
                message = f'Hello!!! have {total_follow_up} customers to follow up with, please add customers to the database so than i can do my job'
                sendWhatsappMessage(fromId, message)
            if agent.whatsapp_number_2:
                fromId = agent.whatsapp_number_1
                message = f'Hello!!! have {total_follow_up} customers to follow up with, please add customers to the database so than i can do my job'
                sendWhatsappMessage(fromId, message)
    else:
        if agent.follow_up_notification | agent.midday_report_notification | agent.evening_report_notification:
            if agent.whatsapp_number_1:
                fromId = agent.whatsapp_number_1
                message = f'Hello!!! have only {total_follow_up} customers to follow up with, imagine if you can give me more, More follow-up equals more engagement which equals to more sales'
                sendWhatsappMessage(fromId, message)
            if agent.whatsapp_number_2:
                fromId = agent.whatsapp_number_1
                message = f'Hello!!! have only {total_follow_up} customers to follow up with, imagine if you can give me more, More follow-up equals more engagement which equals to more sales'
                sendWhatsappMessage(fromId, message)           

# leads warmup agent
def follow_up_tasks_today():
    """
    This function checks all tasks in TaskPipeline that have a follow-up date of today
    and initiates a follow-up process for each of them.
    
    Returns:
    - A list of follow-up results for each customer.
    """
    company, created = CompanyInformation.objects.get_or_create(id=1, defaults={"company_name": "Your Site"})
    agent = AI_Agent.objects.all().order_by('id').first()
    if not agent:
        agent = AI_Agent.objects.create(agent_name="sales agent")
    # Get the current date
    current_date = timezone.now().date()

    
    products , no_products = get_company_products()
    if not products:
        products = company.products_summary

    promotions = get_company_promotions()
    # Get all tasks with a follow-up date of today
    tasks_to_follow_up = TaskPipeline.objects.filter(follow_up_date=current_date, done=False).order_by('id')[:2]

    # Iterate over each task and follow up with the respective customer
    for task in tasks_to_follow_up:
        customer = task.customer
        
        # Get the past conversation history and check if it's the first interaction
        past_history, is_first_interaction = get_past_conversations(customer)

        # Prepare the introduction message if it's the first interaction
        if is_first_interaction:
            introduction_message = f"Hello! I’m {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'SalesGenie'}, your AI assistant working with {company.company_name if company and hasattr(company, 'acompany_name') else 'Salesflow Pro'}. "
        else:
            introduction_message = ""

        # getting guidin sops depending on customer sales funnel stage
        instructions = SalesFunnelStageInstruction.objects.filter(funnel_stage=customer.funnel_stage).first()
        if instructions:
            follow_up_instructions= SalesFunnelStageInstruction.objects.filter(funnel_stage=customer.funnel_stage).first()
        else:
            follow_up_instructions= FOLLOW_UP_INSTRUCTIONS.get(customer.funnel_stage, """
                Goal: Engage prospects who show interest.
                SOP:
                Segment leads based on initial responses or missed calls.
                Call or WhatsApp them within 24-48 hours to follow up on their interest.
                Send personalized content via WhatsApp or SMS (e.g., case studies, testimonials).
                Offer to answer any questions or schedule a live demo.
                Track their engagement by noting call responses or content read in WhatsApp.
            """)
        
        # Prepare the full prompt including the introduction if necessary
        if company.field_of_operation == "software as a service" :
            prompt = f""""
                here is our 
                Company description: {company.company_description},
                Product/Service being offered: {products}.
                current promotional campaigns : {promotions}
                Customer's name: {customer.name if customer and hasattr(customer, 'name') else ''}.
                Past conversation history:
                {past_history}
                Act as an experienced AI follow-up agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'SalesGenie'}, representing {company.company_name}. focused on re-engaging leads for real estate and SaaS products. Your primary objective is to initiate responses from clients, regardless of their sales funnel stage, and use their replies to steer the conversation toward eventual conversion. Craft each message in a way that encourages clients to reply, and tailor responses to maintain continuity based on the context of previous conversations. Leverage SPIN Selling, Influence, and The Challenger Sale frameworks as follows:

                Customer Engagement and Questioning (SPIN Framework):

                Cold Leads: Start with Situation questions that are easy to answer and directly related to the lead's business or goals, to gather context and show genuine interest.
                Warm Leads: Progress to Problem and Implication questions that resonate with their previously shared concerns or business challenges.
                Hot Leads: Use Need-Payoff questions that highlight the AI’s benefits for their specific needs, emphasizing how the product could directly impact their success, ROI, or efficiency.
                Key Focus: End each message with a question or statement that prompts a response, such as “Does this sound like it could help with your goals?” or “I’d love to know your thoughts on this.”

                Building Influence and Authority (Cialdini’s Principles):

                Reciprocity: Offer value-first, such as relevant insights, tips, or exclusive information that applies to the lead’s industry (e.g., market trends, cost-saving strategies).
                Authority: Demonstrate expertise by referencing case studies, testimonials, or client success stories to build trust and credibility.
                Social Proof: Use relatable examples, like highlighting other clients in the same industry, to increase the appeal and relevance of the solution.
                Challenging Clients’ Perspectives (The Challenger Sale):

                For Unsure Leads: Use gentle, thought-provoking questions to challenge their current methods or assumptions, helping them see the benefits of re-engaging and taking next steps.
                For Warm/Hot Leads: Emphasize untapped opportunities that the AI follow-up agent can help them unlock, such as improving lead qualification, maximizing outreach, or reducing costs through automation.
                Objection Handling and Escalation:

                Address objections with clarity, presenting solution-oriented responses that respect the client’s concerns. For example, if they are concerned about cost, emphasize potential ROI or efficiency improvements.
                If the objection requires more detailed expertise, smoothly escalate to a human representative and offer to set up a call or conversation with an expert for further details.
                Conversational Flow:

                Maintain a natural flow by using questions or prompts that require a response, tailored to the client’s context. Examples include, “What’s your current approach for reaching out to leads?” or “How do you feel about exploring a tool to automate follow-ups?”
                Adapt each follow-up based on prior interactions, showing that the AI remembers past conversations and is actively interested in their unique needs.
                Tailoring Responses to Specific Needs:

                For Real Estate Leads: Focus on urgency, availability of properties, or ROI on rental investments.
                For SaaS Leads: Highlight benefits related to scalability, customer engagement, or maximizing software efficiencies to boost lead management.
                End Goal:

                Continuously guide the conversation toward re-engagement, with a focus on booking a demo, scheduling a call, or discussing details that bring the lead closer to conversion.
                Use messages that naturally encourage responses, ensuring clients remain engaged and willing to share more about their needs, creating opportunities to position the product as their ideal solution.
                The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
                format it for whatsap conversation.
                """
            
        elif company.field_of_operation == "real estate" :
            prompt = f"""
            here is our 
                Company description: {company.company_description},
                Product/Service being offered: {products}.
                current promotional campaigns : {promotions}
                Customer's name: {customer.name if customer and hasattr(customer, 'name') else ''}.
                Past conversation history:
                {past_history}
            Act as an experienced AI real estate follow-up agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'SalesGenie'}, representing {company.company_name}. targeting clients who have shown interest in rental properties, first homes, or real estate investments. Your primary goal is to re-engage leads based on their last interaction, maintain a natural conversational flow, and craft messages that encourage responses, thereby keeping clients actively engaged. Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, tailoring to the following specifics:

            Contextual Engagement and Questioning (SPIN Framework):

            Exploring Clients: Use Situation questions to re-establish contact and build rapport. Reference the last point in their search or inquiry, such as “Are you still interested in exploring properties in [location]?” or “Has anything changed in what you’re looking for since we last spoke?”

            Evaluating Clients: Transition to Problem and Implication questions to remind them of specific needs they previously mentioned, like budget or location. Engage by asking, “Have you come across any challenges in your search so far?” or “Would it help to explore options with better financing terms?”

            Ready to Purchase Clients: Emphasize Need-Payoff questions, focusing on the unique benefits of available properties. Keep the message short but impactful, such as “I found a property that checks off your requirements list—would you like more details?”

            Building Influence and Authority (Cialdini’s Principles):

            Reciprocity: Share value-driven insights, like “Just wanted to send you a quick update on rental trends in [location]—I think you’ll find it helpful!” or “Here’s a tip that might make your property search easier.”

            Authority: Reference successful experiences of similar clients who found their ideal properties with your help, positioning the AI as a knowledgeable assistant. E.g., “I recently helped a client find a great property near [landmark]—would you like to explore similar options?”

            Social Proof: Mention stories of satisfied clients in a similar situation. For example, “Many clients found value in looking at properties just outside the main area for better deals—would you like to check a few of these out?”

            Challenging Clients’ Perspectives (The Challenger Sale):

            For Clients Considering Alternative Options: Encourage them to reconsider overlooked opportunities by introducing new ideas or property types, e.g., “Have you considered [property type] in [neighborhood]? It might offer more value within your budget.”

            For Investment Seekers: Prompt a response by suggesting untapped market opportunities, such as “I found a property with promising ROI potential—are you interested in seeing the details?”

            Objection Handling and Re-engagement:

            Address Objections: If they had previous hesitations, respond with a solution-oriented message and include an invitation for further discussion. For example, “I know the location was a concern for you—would it help if we explored properties with better access to transit?”

            Escalate to Expert Assistance: For complex queries, smoothly offer to connect them with a real estate expert, e.g., “Would you like me to schedule a quick call with an agent to answer any specific questions?”

            Conversational Flow and Prompting Responses:

            Follow-Up Questions: Use follow-up questions based on previous conversations, such as “Are you still considering a move within [timeframe]?” or “Would a virtual tour make it easier to decide on some options?”

            Engagement and Action Triggers: End each message with an action-triggering question that makes it easy for clients to respond. Example: “What’s your preferred move-in date so we can narrow down options?” or “Which feature matters most to you—location or amenities?”

            Tailoring Responses to Specific Needs:

            For Rental Clients: Discuss lease terms, neighborhood amenities, and proximity to conveniences. Prompt with questions like “Is proximity to work still a priority for you?”

            For First-Time Homebuyers: Emphasize affordability and financing, with questions like “Would you like information on financing options for first-time buyers?”

            For Real Estate Investors: Focus on ROI, growth areas, and property appreciation rates. Engage with prompts like “Are you looking for properties with rental income potential?”

            End Goal:

            Drive Engagement: Keep responses open-ended but engaging, e.g., “Would you like me to send over a few options that meet your latest criteria?”

            Suggest Next Steps: Include gentle CTAs like, “How about a quick call to go over the options I found?” or “Would you like to schedule a viewing to get a feel for the area?"
            The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
         format it for whatsap conversation.
            """

        elif company.field_of_operation == "automotive" :
            prompt = f"""
            here is our 
                Company description: {company.company_description},
                Product/Service being offered: {products}.
                current promotional campaigns : {promotions}
                Customer's name: {customer.name if customer and hasattr(customer, 'name') else ''}.
                Past conversation history:
                {past_history}
            Act as an experienced AI automotive follow-up agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'SalesGenie'}, representing {company.company_name}. tasked with re-engaging potential clients interested in purchasing a vehicle, whether it’s their first car, an upgrade, or a premium investment. Your primary goal is to send follow-up messages that prompt clients to respond and re-engage with the process, using contextual cues from previous conversations to continue guiding them toward the right car choices. Use SPIN Selling, Influence, and The Challenger Sale frameworks to shape responses, adapting based on where the client left off in their decision-making process (exploring, evaluating, or ready to purchase). Tailor your responses with the following elements in mind:

            Customer Re-Engagement and Follow-Up Questions (SPIN Framework):

            Exploring Clients: Start with Situation-based follow-ups that ask about their preferences and remind them of previously mentioned criteria. Use openers like, “Are you still interested in exploring fuel-efficient or eco-friendly models?” to re-establish context and gently prompt a response.

            Evaluating Clients: Shift to Problem and Implication follow-ups that help clarify their priorities and address any challenges, such as budget or feature needs. For instance, ask, “Last time we spoke, you mentioned budget as a key factor—would you like to explore pre-owned options within that range?”

            Ready to Purchase Clients: Emphasize Need-Payoff follow-ups that highlight the value of moving forward, using reminders like, “I’ve found a few vehicles that match all your criteria—would you like to schedule a test drive to get a feel for them?”

            Building Influence and Trust (Cialdini’s Principles):

            Reciprocity: Offer something valuable in each follow-up, such as tips on seasonal discounts, financing insights, or quick guides for first-time buyers. For example, “I have a quick guide on the best financing tips for first-time buyers—would you like me to send it over?”

            Authority: Reinforce the AI’s expertise by referencing client success stories relevant to their situation, like helping clients secure cars with similar features or within budget. Say, “Many clients found that exploring pre-owned vehicles opened up more options—would you be interested in discussing this?”

            Social Proof: Mention success stories or testimonials from clients who purchased similar vehicles or found great deals. For instance, “A recent client found their ideal SUV with low mileage and great features. Would you like to see options like this?”

            Challenging Clients’ Perspectives (The Challenger Sale):

            For Clients Still Exploring: Introduce new, relevant options they may not have considered, nudging them to consider possibilities that align with their lifestyle. Ask, “Have you thought about hybrid models? They’re popular among clients looking to save on fuel—would you like details?”

            For Investment or Premium Buyers: Suggest models with strong resale value or unique features, encouraging them to explore options with long-term benefits. Ask, “I found a few limited-edition models with high resale value. Interested in learning more about these options?”

            Objection Handling and Escalation:

            Address Concerns: Use a solution-oriented approach to address common objections about budget, features, or model type. For example, “If the budget is still a consideration, we have new pre-owned arrivals that meet your criteria. Would you like details?”

            Escalate to Expert Help: If the client has complex needs, smoothly transition the conversation to a human agent, offering to arrange a call or meeting. For example, “I can connect you with one of our financing experts to discuss the options—would you like me to set that up?”

            Conversational Flow and Personalized Follow-Up:

            Keep Responses Open-Ended: Use follow-ups that are likely to get a response, such as “What’s most important to you in a car right now—fuel efficiency, safety, or luxury?”

            Mention Specific Preferences: Reference client preferences and details from previous interactions to show attentiveness, like “You mentioned a preference for SUVs with advanced safety features—would you like to see the newest models?”

            Tailoring Follow-Ups to Specific Needs:

            For First-Time Buyers: Provide insights on affordable options and financing help. Example: “Are you still interested in learning about financing options for first-time buyers?”

            For Clients Upgrading: Highlight features that represent an upgrade, like new tech or advanced safety options. Example: “I’ve found a few models with all the latest tech and safety features—would you like a look?”

            For Premium or Investment Buyers: Focus on luxury options, high resale value, and unique features. Example: “I have a few premium vehicles with strong resale potential—would that be something you’d like to discuss?”

            End Goal:

            Encourage Immediate Next Steps: Guide clients towards specific actions, like scheduling a test drive, getting more vehicle options, or connecting with a financing expert.

            Prompt for Response with CTAs: Each message should include a call-to-action that encourages reply, such as, “Would a quick look at some of our latest pre-owned arrivals help with your decision?” or “Would you like to set up a test drive to experience this model firsthand?”
            The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
            format it for whatsap conversation.
            """

        else:
            prompt = f"""
                {introduction_message}

                You are an AI sales assistant named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'SalesGenie'}, representing {company.company_name}. Your goal is to engage the customer by drawing from past conversations to create a friendly, helpful, and familiar outreach.

                Customer's current stage in the sales funnel: {customer.funnel_stage}.
                Customer's name: {customer.name if customer and hasattr(customer, 'name') else 'Customer'}.
                Product/Service being promoted: {products}.
                current promotional campaigns : {promotions}
                Company description: {company.company_description}.

                Past conversation history:
                {past_history}

                Approach:
                - Start by warmly acknowledging the previous conversation or a specific detail that shows continuity.
                - Use a friendly, personable tone as if you're reconnecting with an old friend, showing genuine interest in their progress or needs since the last chat.
                - Address the customer's specific needs in a helpful and engaging manner, relevant to their current stage in the funnel.
                - If this is the first interaction, introduce yourself in a concise, friendly way. If they need additional support, reassure them that a human agent is available.

                Response guidelines:
                - Be concise, direct, and aim for a message length that encourages easy reading (preferably under 350 characters).
                - Craft the message to maximize the chance of a response, balancing friendly familiarity with helpful insight.

                {follow_up_instructions}
                """


        # Call OpenAI API to generate a response based on the dynamic prompt
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful AI sales assistant."},
                {"role": "user", "content": prompt}
            ]
        )

        # Parse the response
        ai_response = response['choices'][0]['message']['content']

        # sending the follow up message 
        fromId = customer.phone_number
        message = ai_response
        sendWhatsappMessage(fromId, message)
        
        # Save AI's folow up message 
        Conversation.objects.create(
            customer=customer,
            message=ai_response,
            sender='AI'
        )
        # Mark the task as done (or update it as necessary)
        task.done = True
        task.save()
        if agent.follow_up_notification:
            if agent.whatsapp_number_1:
                fromId = agent.whatsapp_number_1
                customer_name = customer.name if customer.name else customer.phone_number
                message = f'i have followed up with {customer_name}, our previous conversation was on {customer.last_talked}'
                sendWhatsappMessage(fromId, message)
            if agent.whatsapp_number_2:
                fromId = agent.whatsapp_number_1
                customer_name = customer.name if customer.name else customer.phone_number
                message = f'i have followed up with {customer_name}, our previous conversation was on {customer.last_talked} '
                sendWhatsappMessage(fromId, message)
        # update last talked
        customer.last_talked = timezone.now().date()
        customer.save()

    return True

# leads warmup agent 2
def follow_up_immediately(fromId):
    """
    This function follow up with customer immediately after being added to the database.
    
    Returns:
    - A list of follow-up results for each customer.
    """
    company, created = CompanyInformation.objects.get_or_create(id=1, defaults={"company_name": "Your Site"})
    agent = AI_Agent.objects.all().order_by('id').first()
    if not agent:
        agent = AI_Agent.objects.create(agent_name="sales agent")
    # Get the current date
    current_date = timezone.now().date()

    
    products , no_products = get_company_products()
    if no_products:
        products = company.products_summary

    promotions = get_company_promotions()
    # Iterate over each task and follow up with the respective customer
    customer = Customer.objects.filter(phone_number=fromId).first()
    interactions = Interaction.objects.filter(customer=customer).order_by('-id').first()
    
    if interactions:
        last_interaction_summary = interactions.conversation_summary
        if interactions.interaction_place == 'your shop':
            refferal_source = f'visited us at our shop'
        elif interactions.interaction_place == 'customers shop':
            refferal_source = f'reach out at {interactions.interaction_place}'
        elif interactions.interaction_place == 'call':
            refferal_source = f'reach out through {interactions.interaction_place}'
        else:
            refferal_source = f'i interacted with online'
    else:
        refferal_source=''
        last_interaction_summary=''
    chats = Conversation.objects.filter(customer=customer, sender='customer')
    if chats:
    # Get the past conversation history and check if it's the first interaction
        past_history= get_past_conversations(customer)

        
        
        # Prepare the full prompt including the introduction if necessary
        prompt = f"""
            You are an AI sales agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, 
            representing {company.company_name}.
            write a proffessional and personalized follow-up message for a customer named {customer.name}
            whose description is {customer.description}
            and our interaction summary is {last_interaction_summary}
            that i just {refferal_source}
            The message should be appreciative, warm and brief mentioning the interaction and expressing a desire to stay in touch and learn from each other.
            format it for whatsap conversation.

            for additional information that will help you find below
            Product/Service being promoted: {products}.
            current promotional campaigns : {promotions}
            Company description: {company.company_description}.
            Past conversation history:
            {past_history}

            """


        # Call OpenAI API to generate a response based on the dynamic prompt
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You an AI sales agent."},
                {"role": "user", "content": prompt}
            ]
        )

        # Parse the response
        ai_response = response['choices'][0]['message']['content']

        # sending the follow up message 
        message = ai_response
        sendWhatsappMessage(fromId, message)
        
        # Save AI's folow up message 
        Conversation.objects.create(
            customer=customer,
            message=ai_response,
            sender='AI'
        )
    else:
        if customer.niche :
            message = customer.niche.outreach_message
            sendWhatsappMessage(fromId, message)
            # Save AI's folow up message 
            Conversation.objects.create(
                customer=customer,
                message=message,
                sender='AI'
            )
        pass
    if agent.follow_up_notification:
            if agent.whatsapp_number_1:
                fromId = agent.whatsapp_number_1
                customer_name = customer.name if customer.name else customer.phone_number
                message = f'i have followed up with {customer_name}, who you have recently added to the database'
                sendWhatsappMessage(fromId, message)
            if agent.whatsapp_number_2:
                fromId = agent.whatsapp_number_1
                customer_name = customer.name if customer.name else customer.phone_number
                message = f'i have followed up with {customer_name}, who you have recently added to the database'
                sendWhatsappMessage(fromId, message)
        # update last talked
    customer.last_talked = timezone.now().date()
    customer.save()
    return True

def immediatelyFollowUpWithCustomer(fromId):
    message = follow_up_immediately(fromId)
    sendWhatsappMessage(fromId, message)

def aiWorkReport():
    current_time = datetime.now().time()
    cutoff_time = datetime.strptime('18:00:00', '%H:%M:%S').time()
    agent = AI_Agent.objects.all().order_by('id').first()
    if not agent:
        agent = AI_Agent.objects.create(agent_name="sales agent")
    if current_time >= cutoff_time:
        if AiReport.objects.filter(ai=agent).exists():
            
            today = date.today()
            last_update_instance = AiReport.objects.first()
            if last_update_instance.last_updated < today:
                
                customers = Customer.objects.annotate(unread_count=Count('conversations', filter=Q(conversations__read=False)))
                chats = Conversation.objects.filter(date_added=today, sender='AI').count()
                tasks = TaskPipeline.objects.filter(follow_up_date=today, done=True).count()
            
                last_update_instance.save()
                if agent.follow_up_notification | agent.midday_report_notification | agent.evening_report_notification:
                    if agent.whatsapp_number_1:
                        fromId = agent.whatsapp_number_1
                        message = f'Evening %OA Here is my Today Work Report %OA I have followed up with {tasks} customers %OA I have responded to {customers} customers %OA I have send a total of{chats} messages '
                        sendWhatsappMessage(fromId, message)
                    if agent.whatsapp_number_2:
                        fromId = agent.whatsapp_number_1
                        message = f'Evening %OA Here is my Today Work Report %OA I have followed up with {tasks} customers %OA I have responded to {customers} customers %OA I have send a total of{chats} messages '
                        sendWhatsappMessage(fromId, message)
            else:
                pass
        else:
            AiReport.objects.create(ai=agent, send = True)
            today = date.today()
            customers = Customer.objects.annotate(unread_count=Count('conversations', filter=Q(conversations__read=False)))
            chats = Conversation.objects.filter(date_added=today, sender='AI').count()
            tasks = TaskPipeline.objects.filter(follow_up_date=today, done=True).count()
            if agent.follow_up_notification | agent.midday_report_notification | agent.evening_report_notification:
                if agent.whatsapp_number_1:
                    fromId = agent.whatsapp_number_1
                    message = f'Evening %OA Here is my Today Work Report %OA I have followed up with {tasks} customers %OA I have responded to {customers} customers %OA I have send a total of{chats} messages '
                    sendWhatsappMessage(fromId, message)
                if agent.whatsapp_number_2:
                    fromId = agent.whatsapp_number_1
                    message = f'Evening %OA Here is my Today Work Report %OA I have followed up with {tasks} customers %OA I have responded to {customers} customers %OA I have send a total of{chats} messages '
                    sendWhatsappMessage(fromId, message)
    else: 
        return


def chatbotResponse(user_message, history):
    """
    Generates a follow-up message for a customer based on user input and chat history.
    
    Parameters:
    - user_message: The latest message from the user.
    - history: List of past chat messages to provide context.
    
    Returns:
    - The AI-generated response.
    """
    # Retrieve company and agent information
    company, created = CompanyInformation.objects.get_or_create(id=1, defaults={"company_name": "Your Site"})
    agent = AI_Agent.objects.all().order_by('id').first()
    if not agent:
        agent = AI_Agent.objects.create(agent_name="Sales Agent")

    # Fetch products and promotions
    products, no_products = get_company_products()
    if no_products:
        products = company.products_summary
    promotions = get_company_promotions()

    # # Prepare the conversation history
    # history_messages = "\n".join([f"{msg['role'].capitalize()}: {msg['content']}" for msg in history])
    history_messages = []
    for message in history:
        history_messages.append({"role": "user", "content": message.get('user', '')})
        history_messages.append({"role": "assistant", "content": message.get('bot', '')})
    
    # Formulate the prompt with conversation history and user message
    
    if company.field_of_operation == "software as a service" :
        prompt = f"""
        here is our: 
        company description : {company.company_description}.
        product/service you're selling: {products}.
        current promtions and camapigns are {promotions}
        
        Act as an experienced AI sales agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, working for {company.company_name} targeting real estate agents and software/SaaS sellers. Your primary goal is to initiate and nurture meaningful conversations that lead to sales conversions, adapting your responses based on the lead's stage in the sales funnel (cold, warm, or hot). Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, tailoring to the following specifics:

        1. Customer Engagement and Questioning (SPIN Framework):
        Cold Leads: Focus on Situation questions to gather context and understand business goals.
        Warm Leads: Transition more quickly into Problem and Implication questions to uncover pain points.
        Hot Leads: Focus on Need-Payoff questions, emphasizing AI’s specific benefits (e.g., better lead conversion, cost savings).
        2. Building Influence and Authority (Cialdini’s Principles):
        Use reciprocity by offering value-first tips or resources.
        Authority: Display expertise by referencing successful case studies and client testimonials.
        Social Proof: Tailor success stories to the lead’s industry (e.g., real estate or SaaS).
        3. Challenging Clients’ Perspectives (The Challenger Sale):
        Gently challenge leads’ current thinking, especially for leads who are unsure about AI. Position AI as a solution to untapped opportunities, such as improving lead qualification or boosting outreach efficiency.
        4. Objection Handling and Escalation:
        Address objections with solution-oriented responses. If the objection is complex, smoothly escalate to a human representative, offering to connect the lead to an expert.
        5. Conversational Flow:
        Always ask follow-up questions to ensure engagement. Adapt follow-up questions based on lead responses, and maintain a natural flow in the conversation. Example follow-up questions include: “What do you think about this feature?” or “What challenges are you currently facing in your business?”
        6. Tailoring Responses to Specific Needs:
        For Real Estate Agents: Focus on urgency, market trends, and local property features.
        For SaaS Sellers: Emphasize ROI, scalability, and lead management efficiency.
        7. End Goal:
        Continuously steer the conversation towards conversion. Reiterate the benefits, offer a demo, or suggest next steps, such as booking a call or receiving additional details.
        Below is the past conversation history: {history_messages}
        Now, the customer said: {user_message}
        The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
        format it for whatsap conversation.
        """
    elif company.field_of_operation == "real estate" :  
        prompt = f"""
        here is our: 
        company description : {company.company_description}.
        product/service you're selling: {products}.
        current promtions and camapigns are {promotions}
        Act as an experienced AI real estate sales agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, working for {company.company_name} targeting clients looking for rental properties, first homes, or real estate investments. Your primary goal is to initiate and nurture meaningful conversations that guide clients to the right property options, adapting your responses based on the client’s stage in the decision-making process (exploring, evaluating, or ready to purchase). Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, tailoring to the following specifics:

        Customer Engagement and Questioning (SPIN Framework):

        Exploring Clients: Begin with Situation questions to gather context on what they are looking for (rental, first home, or investment).
        Evaluating Clients: Move into Problem and Implication questions to identify their specific needs and pain points (e.g., location preferences, budget constraints).
        Ready to Purchase Clients: Focus on Need-Payoff questions, highlighting how the AI can offer the best deals, investment opportunities, or rental options to save them time and money.
        Building Influence and Authority (Cialdini’s Principles):

        Reciprocity: Provide valuable insights such as market trends, advice on the home-buying process, or investment tips in return for their trust.
        Authority: Display expertise by referencing successful cases of clients finding their ideal properties or successful investment deals.
        Social Proof: Share success stories from clients who have successfully rented homes, purchased their first properties, or made profitable investments, tailored to their specific situation (e.g., first-time home buyers or rental seekers).
        Challenging Clients’ Perspectives (The Challenger Sale):

        For Clients Uncertain About Property Choices: Gently challenge their current thinking by introducing new possibilities or properties they may not have considered. Position the AI as a solution to help them discover hidden gems, better investment opportunities, or properties that align more closely with their needs.
        For Investment Seekers: Encourage clients to explore alternative investment strategies or properties with higher potential returns, focusing on market growth areas or emerging investment opportunities.
        Objection Handling and Escalation:

        Address objections about pricing, location, or property features with solution-oriented responses, offering alternatives that still meet their needs.
        If the client expresses concern about the AI’s recommendations or asks a complex question, escalate the conversation to a human real estate expert, offering to schedule a consultation with an agent for more tailored advice.
        Conversational Flow:

        Always ask follow-up questions to ensure engagement and move the conversation forward. Adapt follow-up questions based on the client’s responses, such as: “What’s your timeline for moving?” or “What’s most important to you when selecting a property?”
        If a client mentions a budget range, ask about their desired amenities or location to refine the search.
        Tailoring Responses to Specific Needs:

        For Rental Clients: Focus on rental prices, lease terms, amenities, and the neighborhood.
        For First-Time Homebuyers: Emphasize affordability, financing options, and proximity to work, schools, or family.
        For Real Estate Investors: Highlight ROI potential, investment strategies, property appreciation rates, and rental income.
        End Goal:

        Continuously steer the conversation towards a property recommendation or action step. Reiterate the AI's ability to simplify property searches, provide valuable market insights, and save time in finding the right match.
        Suggest next steps like scheduling a property tour, receiving property details, or discussing financing options with a human agent.
        Below is the past conversation history: {history_messages}
        Now, the customer said: {user_message} 
        The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
        format it for whatsap conversation.
        """
    elif company.field_of_operation == "automotive" :
        prompt = f"""
            here is our: 
            company description : {company.company_description}.
            product/service you're selling: {products}.
            current promtions and camapigns are {promotions}

            Act as an experienced AI automotive sales agent targeting clients interested in purchasing their dream car, whether it’s a first-time buy, an upgrade, or an investment in a premium vehicle. Your primary goal is to initiate and nurture meaningful conversations that guide clients toward the right car choices, adjusting responses based on the client’s stage in the decision-making process (exploring, evaluating, or ready to purchase). Use SPIN Selling, Influence, and The Challenger Sale frameworks to guide responses, with the following focus areas:

            Customer Engagement and Questioning (SPIN Framework):

            Exploring Clients: Start with Situation questions to understand the client’s general preferences, lifestyle, and what they’re looking for in a car (e.g., family-friendly, luxury, eco-friendly, or performance). Ask openers like, “What’s most important to you in a vehicle—fuel efficiency, comfort, or performance?” to tailor recommendations effectively.

            Evaluating Clients: Shift to Problem and Implication questions, digging deeper into specific needs and challenges, such as budget limits, desired features, or specific models under consideration. Use questions like, “Are you looking for any specific safety features or technology?” to clarify their priorities and uncover potential deal-breakers.

            Ready to Purchase Clients: Focus on Need-Payoff questions that highlight how the AI can provide unique options or help with exclusive financing and limited-time offers (e.g., “Would you be interested in a test drive for our latest model with all the features you’re looking for?”).

            Building Influence and Authority (Cialdini’s Principles):

            Reciprocity: Share valuable insights, such as recent trends in fuel-efficient models, maintenance tips, or updates on the best financing options. This builds trust and provides added value, e.g., “I can share a quick guide on maintaining the longevity of your vehicle—would you like that?”

            Authority: Establish expertise by referencing successful matches, such as helping clients find family SUVs with top safety ratings or matching buyers to luxury vehicles with exceptional resale value. Reinforce your knowledge by explaining unique vehicle benefits in layman’s terms.

            Social Proof: Reference stories from similar clients who successfully found their dream cars—whether a family-friendly SUV, a high-performance sedan, or an eco-friendly hybrid. Example: “Many of my clients have found value in our selection of fuel-efficient models for commuting—would you like to explore those?”

            Challenging Clients’ Perspectives (The Challenger Sale):

            For Clients Who Haven't Considered All Options: Suggest alternative options that align with their lifestyle but add value, e.g., “Have you considered our newest hybrid model? It combines fuel efficiency with high performance and has been popular among clients looking to reduce fuel costs.”

            For Performance or Investment Buyers: Introduce them to models with high resale value or limited edition features, encouraging them to consider cars that provide better long-term value. Example: “Many clients find that investing in a model with high resale potential is beneficial—would you like more details on those options?”

            Objection Handling and Escalation:

            Address Objections: Tackle concerns about budget, features, or vehicle type with solution-oriented responses. For instance, “If budget is a concern, we could look at pre-owned certified vehicles with the same features—would that interest you?”

            Escalate to Expert Assistance: If they have complex questions about financing, trade-ins, or customization, seamlessly escalate to a human sales expert, offering to set up a call or appointment for a deeper discussion.

            Conversational Flow and Follow-up:

            Keep Engagement High: Use follow-up questions based on prior interactions, like “What’s your ideal timeline for purchasing?” or “Would you like to schedule a test drive to see how it feels?”

            Build Long-Term Engagement: Track client preferences and reference them in follow-up messages to show attentiveness, e.g., “I remember you mentioned an interest in fuel efficiency—would you like an update on some of the latest hybrid models?”

            Tailoring Responses to Specific Needs:

            For First-Time Buyers: Focus on budget-friendly, reliable options and financing assistance. Emphasize affordability, easy maintenance, and warranties, with prompts like “Would knowing about financing options help you with budgeting?”

            For Upgraders: Highlight features that represent an upgrade, like advanced tech, safety features, and enhanced comfort. Example: “Would you like to see vehicles with the latest tech features and a bit more space?”

            For Investment or Premium Buyers: Emphasize luxury, unique features, and models with high resale value. Discuss rare options, customizations, or market trends, with questions like “Are you interested in exploring vehicles with exclusive features or limited availability?”

            End Goal:

            Steer Toward Action: Guide clients toward scheduling a test drive, receiving a tailored car list, or discussing financing options with a human agent.

            Use Actionable CTAs: Close with action prompts like, “Would you like to book a test drive this week?” or “I can connect you with a financing specialist if you’re ready to explore payment options.
            Below is the past conversation history: {history_messages}
            Now, the customer said: {user_message} 
            The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
            format it for whatsap conversation.
            """
    else:
        prompt = f"""
            You are an AI sales agent named {agent.agent_name if agent and hasattr(agent, 'agent_name') else 'Sales Agent'}, 
            representing {company.company_name}.
            offer customer support sevices .

            Previous conversation history:
            {history_messages}

            New customer message: {user_message}

            Additional information:
            Product/Service being promoted: {products}.
            Current promotional campaigns: {promotions}.
            Company description: {company.company_description}.

            you should not hullucinate just answer correct
            The message should be concise and brief and not more than 350 characters unless asked for indepth explanation.
            format it for whatsap conversation.
        """

    # Call OpenAI API to generate a response based on the dynamic prompt
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[
            {"role": "assistant", "content": "You are an AI sales agent."},
            {"role": "user", "content": prompt}
        ]
    )

    # Parse the response
    ai_response = response['choices'][0]['message']['content']

    # Send follow-up notifications if enabled
    if agent.follow_up_notification:
        notification_message = 'I have responded to a customer on your website chatbot'
        if agent.whatsapp_number_1:
            sendWhatsappMessage(agent.whatsapp_number_1, notification_message)
        if agent.whatsapp_number_2:
            sendWhatsappMessage(agent.whatsapp_number_2, notification_message)

    return ai_response
